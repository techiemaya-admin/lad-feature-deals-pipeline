/**
 * Centralized Logger for LAD Architecture
 * Replaces all console.* statements with proper logging levels
 * Provides structured logging with timestamps and context
 */

const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};

const CURRENT_LOG_LEVEL = process.env.LOG_LEVEL 
  ? LOG_LEVELS[process.env.LOG_LEVEL.toUpperCase()] 
  : (process.env.NODE_ENV === 'production' ? LOG_LEVELS.INFO : LOG_LEVELS.DEBUG);

/**
 * Format log message with timestamp and level
 */
function formatMessage(level, message, context = {}) {
  const timestamp = new Date().toISOString();
  const contextStr = Object.keys(context).length > 0 ? ` ${JSON.stringify(context)}` : '';
  return `[${timestamp}] [${level}]${contextStr} ${message}`;
}

/**
 * Sanitize sensitive data from logs
 */
function sanitize(data) {
  if (typeof data !== 'object' || data === null) return data;
  
  const sensitiveKeys = ['password', 'token', 'secret', 'apiKey', 'authorization', 'cardNumber', 'cvv', 'ssn'];
  const sanitized = { ...data };
  
  for (const key in sanitized) {
    if (sensitiveKeys.some(sk => key.toLowerCase().includes(sk))) {
      sanitized[key] = '***REDACTED***';
    } else if (typeof sanitized[key] === 'object') {
      sanitized[key] = sanitize(sanitized[key]);
    }
  }
  
  return sanitized;
}

/**
 * Log debug messages (verbose, development only)
 */
function debug(message, context = {}) {
  if (CURRENT_LOG_LEVEL <= LOG_LEVELS.DEBUG) {
    console.log(formatMessage('DEBUG', message, sanitize(context)));
  }
}

/**
 * Log informational messages
 */
function info(message, context = {}) {
  if (CURRENT_LOG_LEVEL <= LOG_LEVELS.INFO) {
    console.log(formatMessage('INFO', message, sanitize(context)));
  }
}

/**
 * Log warning messages
 */
function warn(message, context = {}) {
  if (CURRENT_LOG_LEVEL <= LOG_LEVELS.WARN) {
    console.warn(formatMessage('WARN', message, sanitize(context)));
  }
}

/**
 * Log error messages
 */
function error(message, errorObj = null, context = {}) {
  if (CURRENT_LOG_LEVEL <= LOG_LEVELS.ERROR) {
    const errorContext = {
      ...sanitize(context),
      ...(errorObj && {
        error: errorObj.message,
        stack: errorObj.stack,
        code: errorObj.code
      })
    };
    console.error(formatMessage('ERROR', message, errorContext));
  }
}

module.exports = {
  debug,
  info,
  warn,
  error,
  LOG_LEVELS
};
