/**
 * Schema Helper for LAD Multi-Tenancy
 * Dynamically resolves database schema from request context
 * Ensures no hardcoded schema names in queries
 */

const logger = require('./logger');

// Default schema for development/fallback
const DEFAULT_SCHEMA = process.env.DB_SCHEMA || 'lad_dev';

/**
 * Get schema from request context
 * Priority: req.user.schema > req.headers['x-tenant-schema'] > environment default
 * 
 * @param {Object} req - Express request object
 * @returns {string} Schema name
 */
function getSchema(req) {
  // Priority 1: From authenticated user context
  if (req && req.user && req.user.schema) {
    return req.user.schema;
  }
  
  // Priority 2: From tenant header (for service-to-service calls)
  if (req && req.headers && req.headers['x-tenant-schema']) {
    return req.headers['x-tenant-schema'];
  }
  
  // Priority 3: Environment default (development only)
  logger.debug('Using default schema', { schema: DEFAULT_SCHEMA });
  return DEFAULT_SCHEMA;
}

/**
 * Validate tenant context exists
 * Throws error if tenant_id is missing from request
 * 
 * @param {Object} req - Express request object
 * @throws {Error} If tenant context is missing
 */
function validateTenantContext(req) {
  if (!req.user || !req.user.tenant_id) {
    const error = new Error('Tenant context required - missing tenant_id in request');
    error.code = 'TENANT_CONTEXT_MISSING';
    error.statusCode = 403;
    throw error;
  }
  return req.user.tenant_id;
}

/**
 * Extract tenant_id from request with validation
 * 
 * @param {Object} req - Express request object
 * @returns {string} tenant_id
 * @throws {Error} If tenant_id is missing
 */
function getTenantId(req) {
  return validateTenantContext(req);
}

/**
 * Get both schema and tenant_id from request
 * 
 * @param {Object} req - Express request object
 * @returns {Object} { schema, tenant_id }
 */
function getTenantContext(req) {
  const tenant_id = validateTenantContext(req);
  const schema = getSchema(req);
  
  return { schema, tenant_id };
}

module.exports = {
  getSchema,
  getTenantId,
  validateTenantContext,
  getTenantContext,
  DEFAULT_SCHEMA
};
